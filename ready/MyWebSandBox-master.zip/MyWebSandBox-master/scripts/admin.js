(function () {
    const BASE_URL= 'https://localhost:7183/api/films'   // переименовала переменную и удалила слеш в конце
    //const mainUrl = 'https://localhost:7126/api/films/'  // было до этого

    const table_body = document.getElementById('filmsTableBody');
    // добавила
    const filmsCount = document.getElementById('filmsCount');
    //// удалила // было
    //const counter = document.querySelector('.counter h2');

    const btn_add = document.getElementById('add_btn');
    const btn_edit = document.getElementById('edit_btn');
    const btn_delete = document.getElementById('delete_btn');
    const btn_refresh = document.getElementById('refresh_btn');

    //модальное окно сохранения
    const modal = document.getElementById('modal');
    const modalClose = document.getElementById('modal_close');
    const modalSave = document.getElementById('added-film_btn-save');
    ////добавлиа
    const modalTitle = document.getElementById('modalTitle');
    ////удалила // было
    //const modalTitle = document.querySelector('.container h1');
    ////добавлиа
    const form = document.getElementById('filmForm');
    ////удалила // было
    //const form = document.getElementById('form');
    const input_title = document.getElementById('title_input');
    const input_description = document.getElementById('description_input');
    const input_year = document.getElementById('year_input');
    const input_photoPath  = document.getElementById('photo_path'); // поправила // было: input_PhotoPath


    ////поправила
    let editingId = null; // id редактируемого фильма
    ////было до этого
    //let selectedFilmId = null;


    // функции для работы с модальным окном

    function openModal(title, filmData = null) {
        modalTitle.textContent = title;
        form.reset();
        editingId = null;

        if (filmData) {
            input_title.value = filmData.title || '';
            input_description.value = filmData.description || '';
            input_year.value = filmData.year || '';
            input_photoPath.value = filmData.photoPath || '';
            editingId = filmData.id;
        }

        modal.classList.add('open');
        console.log('Модальное окно открыто.');
    }
    ////удалила // было до этого
    //function openModal() {
    //    //form.reset();
    //    modal.classList.add('open');
    //    console.log('Модальное окно открыто.')
    //}

    function closeModal() {
        modal.classList.remove('open');
        console.error('Модальное окно закрыто.')

    }


    // добавила +++
    // загрузка всех фильмов
    async function loadFilms() {
        try {
            const response = await fetch(`${BASE_URL}/get`);
            if (!response.ok) {
                throw new Error(`Ошибка: ${response.status}`);
            }
            const films = await response.json();
            console.log('Получено фильмов:', films.length); // ++
            renderTable(films);
            updateCount(films.length);

            return films;
        } catch (error) {
            console.error('Ошибка загрузки фильмов:', error);
            alert('Не удалось загрузить список фильмов');

            return [];
        }
    }


    // добавила +++
    // отображение таблицы
    function renderTable(films) {
        table_body.innerHTML = '';
        if (!films || films.length === 0) {
            const row = document.createElement('tr');
            row.innerHTML = '<td colspan="6" style="text-align:center;">Нет фильмов</td>';
            table_body.appendChild(row);
            return;
        }

        films.forEach(f => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${f.id}</td>
                <td>${f.title || ''}</td>
                <td>${(f.description || '').substring(0, 50)}${(f.description || '').length > 50 ? '...' : ''}</td>
                <td>${f.year || ''}</td>
                <td>${f.photoPath || ''}</td>
                <td>
                    <button class="btn-edit" data-id="${f.id}">✎</button>
                    <button class="btn-delete" data-id="${f.id}">✕</button>
                </td>
            `;
            table_body.appendChild(row);
        });

        // обработчики для кнопок в таблице
        document.querySelectorAll('.btn-edit').forEach(btn => {
            btn.addEventListener('click', () => editFilm(parseInt(btn.dataset.id)));
        });

        document.querySelectorAll('.btn-delete').forEach(btn => {
            btn.addEventListener('click', () => deleteFilm(parseInt(btn.dataset.id)));
        });
    }


    // добавила +++
    // обновление счетчика
    function updateCount(count) {
        if (filmsCount) {
            filmsCount.textContent = count;
        }

        //filmsCount.textContent = count;  // было до этого
    }


    // поправила +++
    // добавление фильма
    async function addFilm(filmData) {
        try {
            const response = await fetch(`${BASE_URL}/add`, {
                method: 'POST',
                //headers: { 'Content-Type': 'application/json' }, // было до этого
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(filmData)
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Ошибка ${response.status}: ${errorText}`);
            }

            const newFilm = await response.json();
            console.log('Фильм добавлен:', newFilm);
            closeModal();
            await loadFilms();
            alert('Фильм успешно добавлен!');
        } catch (error) {
            console.error('Ошибка добавления:', error);
            alert('Не удалось добавить фильм: ' + error.message);
        }
    }

    ////удалила // было до этого
    //async function addFilm(filmData)
    //{
    //    const response = await fetch(mainUrl,
    //        {
    //            method: 'POST',
    //            headers: {'Content-Type': 'application/json'},
    //            body: JSON.stringify(filmData)
    //        });
    //    if (!response.ok)
    //    {
    //        const errorMessage = await response.text();
    //        throw new Error(`Ошибка: ${response.status} , ${response.statusText}`);
    //    }
    //
    //    const film = await response.json();
    //    closeModal();
    //    //Перезагрузить список
    //    console.log(`Фильм ${film.title} добавлен успешно.`);
    //}
    //
    //btn_add.addEventListener('click', openModal);
    //modalClose.addEventListener('click', closeModal);
    //modalSave.addEventListener('click', function(e)
    //{
    //    e.preventDefault();
    //    const FilmData =
    //        {
    //            title: input_title.value.trim(),
    //            description: input_description.value.trim(),
    //            year: input_year.value.trim(),
    //            photoPath: input_PhotoPath.value.trim()
    //        };
    //    addFilm(FilmData);
    //});




    // добавила +++
    // редактирование фильма
    // сначала получаем данные фильма, которые необходимо отредактировать
    async function editFilm(id) {
        try {
            console.log('Загрузка фильма для редактирования, ID:', id);
            const response = await fetch(`${BASE_URL}/get/${id}`);

            if (!response.ok) {
                throw new Error(`Ошибка: ${response.status}`);
            }
            const film = await response.json();
            console.log('Данные фильма:', film);

            openModal('Редактирование фильма', film);
        } catch (error) {
            console.error('Ошибка загрузки фильма:', error);
            alert('Не удалось загрузить данные фильма');
        }
    }
    // затем редактируем данные этого фильма на новые - само обновление фильма (сохранение изменений)
    async function updateFilm(id, filmData) {
        try {
            console.log('Обновление фильма ID:', id, 'Данные:', filmData);

            const response = await fetch(`${BASE_URL}/update/${id}`, {
                method: 'PUT',
                //headers: { 'Content-Type': 'application/json' },
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(filmData)
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Ошибка ${response.status}: ${errorText}`);
            }

            console.log('Фильм обновлен');
            closeModal();
            await loadFilms();
            alert('Фильм успешно обновлен!');
        } catch (error) {
            console.error('Ошибка обновления:', error);
            alert('Не удалось обновить фильм: ' + error.message);
        }
    }



    // добавила +++
    // удаление фильма
    async function deleteFilm(id) {
        if (!confirm(`Вы уверены, что хотите удалить фильм с ID ${id}?`)) {
            return;
        }

        try {
            console.log('Удаление фильма ID:', id);

            const response = await fetch(`${BASE_URL}/delete/${id}`, {
                method: 'DELETE'
            });

            if (!response.ok) {
                const errorText = await response.text();
                throw new Error(`Ошибка ${response.status}: ${errorText}`);
            }

            console.log('Фильм удален');
            await loadFilms();
            alert('Фильм успешно удален!');
        } catch (error) {
            console.error('Ошибка удаления:', error);
            alert('Не удалось удалить фильм: ' + error.message);
        }
    }



    // добавила +++
    // обработчики событий
    btn_add.addEventListener('click', () => openModal('Добавление нового фильма'));

    btn_edit.addEventListener('click', () => {
        alert('Нажмите кнопку "✎" рядом с нужным фильмом для редактирования');
    });

    btn_delete.addEventListener('click', () => {
        alert('Нажмите кнопку "✕" рядом с нужным фильмом для удаления');
    });

    // кнопка обновить список
    btn_refresh.addEventListener('click', () => {
        console.log('Обновление списка...');
        loadFilms();
    });

    //btn_refresh.addEventListener('click', loadFilms);


    //закрытие модального окна по крестику
    modalClose.addEventListener('click', closeModal);



    // добавила +++
    // закрытие модального окна при клике вне его
    modal.addEventListener('click', (e) => {
        if (e.target === modal) {
            closeModal();
        }
    });



    // добавила +++
    modalSave.addEventListener('click', async function(e) {
        e.preventDefault();

        console.log('Сохранение фильма...');

        //валидация данных
        const title = input_title.value.trim();
        const year = parseInt(input_year.value.trim());

        if (!title) {
            alert('Название фильма обязательно!');
            input_title.focus();
            return;
        }

        if (!year || isNaN(year) || year < 1900 || year > 2100) {
            alert('Введите корректный год (1900-2100)');
            input_year.focus();
            return;
        }

        const filmData = {
            title: title,
            description: input_description.value.trim() || '',
            year: year,
            photoPath: input_photoPath.value.trim() || ''
        };

        console.log('Данные для сохранения:', filmData);

        if (editingId) {
            // редактирование существующего фильма
            await updateFilm(editingId, filmData);
        } else {
            // добавление нового фильма
            await addFilm(filmData);
        }
    });


    // добавила +++
    // загрузка фильмов при открытии страницы
    console.log('Админ-панель загружена');
    loadFilms();



})();