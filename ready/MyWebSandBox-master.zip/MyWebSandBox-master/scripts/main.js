const BASE_URL = 'https://localhost:7183/api/films'

//const BASE_URL = "https://localhost:7126/api/films";  // плменять на свой порт


//GET ALL
async function getAllFilms()
{
    try
    {
        // поправила - добавила:  + "/get"
        const response = await fetch(`${BASE_URL}/get`);
        // const response = await fetch(BASE_URL); // было до этого

        if (!response.ok)
        {
            throw new Error(`Ошибка HTTP ${response.status} : ${response.statusText}`);
        }

        const films = await response.json();

        console.log('Загружены все фильмы:', films); // поправила
        // console.log(films); // было до этого

        return films;

    } catch (error)
    {
        console.error('Не удалось загрузить фильм(ы)', error);

        return null;
    }
}


//GET by ID
async function getById(id)
{
    try
    {
        const response = await fetch(`${BASE_URL}/get/${id}`); // поправила
        //const response = await fetch(BASE_URL + "/" + id);

        if (!response.ok)
        {
            throw new Error(`Ошибка HTTP ${response.status} : ${response.statusText}`);
        }

        const film = await response.json();

        console.log(`Фильм с ID ${id}:`, film); // поправила
        //console.log(film); // было до этого

        return film

    } catch (error) {
        console.error('Не удалось загрузить фильм', error);

        return null;
    }
}

//создание(сбор) карточки фильма\ов (для вставки в HTML)
function Construct(films)
{
    // добавила const
    const film_container = document.getElementById('film-container');
    const error_container = document.getElementById('error-container');

    film_container.innerHTML = '';
    error_container.style.display = 'none';

    if (!films)
    {
        error_container.textContent = 'Не удалось получить фильмы (нет доступа к API)! Попробуйте позже!';
        error_container.style.display = 'block';
        return;
    }

    //поменяла проверку
    // если пришел один фильм, а не массив
    if (!Array.isArray(films)) {
        films = [films];
    }

    if (films.length === 0) {
        error_container.textContent = 'База данных пуста, фильмов нет. Попробуйте позже.';
        error_container.style.display = 'block';
        return;
    }

    ////было
    //if (films.length <= 0)
    //{
    //    error_container.textContent = 'База данных - пустая, фильмов нет. Попробуйте позже.';
    //    error_container.style.display = 'block';
    //    return;
    //}


    films.forEach(f =>
    {
        const card = document.createElement('div');
        card.className = 'movie-card';

        const title = document.createElement('h3');
        //title.textContent = `${f.title} (${f.year})`;
        title.textContent = `${f.title || 'Без названия'} (${f.year || 'N/A'})`;

        const img = document.createElement('img'); // поправила
        //const photopath = document.createElement('img'); // было до этого

        // исправила путь к изображению
        if (f.photoPath && f.photoPath.trim() !== '') {

            // убираем слеш в начале, если он есть
            let imagePath = f.photoPath;
            if (imagePath.startsWith('/')) {
                imagePath = imagePath.substring(1);
            }

            // полный URL к изображению через API  // указала полный относительный путь к файлу // добавила слеш после названия проекта !!!!
            img.src = `C:/project_c_sharp/hw_29062026-05072026/ready/MyWebSandBox-master/${imagePath}`;

        } else {

            // полный URL к изображению через API  // указала полный относительный путь к файлу
            img.src = 'C:/project_c_sharp/hw_29062026-05072026/ready/MyWebSandBox-master/images/logo.png';
        }
        img.alt = `Постер к фильму: ${f.title || 'Фильм'}`; // поправила
        //img.alt = `Постер к фильму: ${f.title}`; // было до этого
        img.onerror = function() {

            // полный URL к изображению через API  // указала полный относительный путь к файлу
            this.src = 'C:/project_c_sharp/hw_29062026-05072026/ready/MyWebSandBox-master/images/logo.png';

        };


        //// было до этого
        //if (!f.photopath)
        //{
        //    photopath.src = '/images/logo.png';
        //}
        //else
        //{
        //    photopath.src = f.photopath;
        //}
        //console.error(`${photopath.src}`);
        //photopath.alt = `Постер к фильму : ${f.title}`;


        const description = document.createElement('p');
        description.textContent = f.description || 'Описание отсутствует';
        //description.textContent = f.description; // было до этого

        const btn_more = document.createElement('a');
        btn_more.className = 'button';
        // ИСПРАВИЛА ПУТЬ К СТРАНИЦАМ ДЕТАЛЕЙ
        btn_more.href = `./pages/F${f.id}_Details.html`; // добавила точку вначале
        //btn_more.href = `/pages/F${f.id}_Details.html`; // было до этого
        btn_more.textContent = 'Подробнее';

        //применяем (сохраняем), вложенные в НОВЫЕ ТЕГИ, данные
        card.appendChild(title);
        card.appendChild(img); // поправила
        //card.appendChild(photopath); // было до этого
        card.appendChild(description);
        card.appendChild(btn_more);

        //сохранили ЦЕЛИКОМ собранную карточку в КОНТЕЙНЕР
        film_container.appendChild(card);
    });
}

async function loadAllData()
{
    const films = await getAllFilms();
    Construct(films);
}

async function loadDataById()
{
    const film = await getById(1); // вручную пока прописываю айди фильма

    //поправила
    if (film) {
        Construct([film]);
    }

    //Construct([film]); // было до этого
}


// можно добавить автоматическую загрузку всех фильмов из БД
// загрузка при открытии страницы
document.addEventListener('DOMContentLoaded', function() {
    loadAllData();
});


//// можно добавить автоматическую загрузку всех фильмов из БД
//// загрузка при открытии страницы
//document.addEventListener('DOMContentLoaded', function() {
//    loadAllData();
//});