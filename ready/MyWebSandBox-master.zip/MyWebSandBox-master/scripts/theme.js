/* добавлена также поддержка страницы admin.html */


document.addEventListener("DOMContentLoaded", function () {
    // находим все кнопки смены темы на странице
    const themeButtons = document.querySelectorAll('.theme-button');

    if (themeButtons.length === 0) {
        console.warn('Кнопки смены темы не найдены... =(');
        return;
    }

    // считываем сохраненную тему
    const savedTheme = localStorage.getItem('theme');

    // применяем сохраненную тему при загрузке
    if (savedTheme === 'dark') {
        document.body.classList.remove('light');
        document.body.classList.add('dark');
        themeButtons.forEach(btn => {
            btn.textContent = 'DARK';
        });
    } else {
        // по умолчанию светлая тема
        document.body.classList.remove('dark');
        document.body.classList.add('light');
        themeButtons.forEach(btn => {
            btn.textContent = 'LIGHT';
        });
    }

    // добавляем обработчик на каждую кнопку
    themeButtons.forEach(themeButton => {
        themeButton.addEventListener('click', function () {
            if (document.body.classList.contains('dark')) {
                // Переключаем на светлую тему
                document.body.classList.remove('dark');
                document.body.classList.add('light');
                localStorage.setItem('theme', 'light');
                themeButtons.forEach(btn => {
                    btn.textContent = 'LIGHT';
                });
                console.log('Смена темы на: LIGHT');
            } else {
                // переключаем на тёмную тему
                document.body.classList.remove('light');
                document.body.classList.add('dark');
                localStorage.setItem('theme', 'dark');
                themeButtons.forEach(btn => {
                    btn.textContent = 'DARK';
                });
                console.log('Смена темы на: DARK');
            }
        });
    });
});



