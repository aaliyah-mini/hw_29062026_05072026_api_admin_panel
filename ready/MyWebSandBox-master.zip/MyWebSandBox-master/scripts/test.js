async function getAllFilms()
{
    const mainUrl = 'https://localhost:7183/api/films/'

    //const mainUrl = 'https://localhost:7126/api/films/';

    const url = mainUrl + 'get';

    try
    {
        const result = await fetch(url);
        if (result.ok)
        {
            const films = await result.json();

            if (films.length > 0)
            {
                console.warn('Фильмы загружены.');
                console.log(films);
            }
            else
            {
                console.error('Данные вернуись путстыми.');
                return [];
            }
        }
    } catch (error)
    {
        console.warn('Не удалось подключитьчся к серверу.')
    }
}