﻿using System.Collections.Generic;
using System.Threading.Tasks;

using hw_admin_panel_29062026_05072026.Models;
using Npgsql;


namespace hw_admin_panel_29062026_05072026.Database
{
    // класс для работы с БД
    public static class FilmData
    {
        // строка подключения к БД в localhost 
        private static string connectionString = "Host=localhost;Port=5432;Database=webFilm;Username=postgres;Password=1234";


        // 1) метод для получения всех фильмов из БД
        public static async Task<List<Film>> GetAllFilmsAsync()
        {
            List<Film> films = new List<Film>();

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();

                string sql = "SELECT * FROM \"Films\" ORDER BY Id";

                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                using (NpgsqlDataReader reader = await command.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        Film film = new Film
                        {
                            Id = reader.GetInt32(0),
                            Title = reader.GetString(1),
                            Description = reader.IsDBNull(2) ? "" : reader.GetString(2),
                            Year = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                            PhotoPath = reader.IsDBNull(4) ? "" : reader.GetString(4)
                        };
                        films.Add(film);
                    }
                }

            }

            return films;
        }



        // 2) метод для получения фильма по ID из БД
        public static async Task<Film> GetFilmByIdAsync(int id)
        {
            Film film = null;

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();

                string sql = "SELECT * FROM \"Films\" WHERE Id = @id";

                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    using (NpgsqlDataReader reader = await command.ExecuteReaderAsync())
                    {
                        if (await reader.ReadAsync())
                        {
                            film = new Film
                            {
                                Id = reader.GetInt32(0),
                                Title = reader.GetString(1),
                                Description = reader.IsDBNull(2) ? "" : reader.GetString(2),
                                Year = reader.IsDBNull(3) ? 0 : reader.GetInt32(3),
                                PhotoPath = reader.IsDBNull(4) ? "" : reader.GetString(4)
                            };
                        }
                    }
                }

            }

            return film;
        }



        // 3) метод для добавления нового фильма в БД
        public static async Task<int> AddFilmAsync(Film film)
        {
            int newId = 0;

            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();

                string sql = @"INSERT INTO ""Films"" (Title, Description, Year, PhotoPath) " +
                            "VALUES(@title, @description, @year, @photoPath) " +
                            "RETURNING Id";


                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@title", film.Title);
                    command.Parameters.AddWithValue("@description", film.Description ?? "");
                    command.Parameters.AddWithValue("@year", film.Year);
                    command.Parameters.AddWithValue("@photoPath", film.PhotoPath ?? "");

                    newId = Convert.ToInt32(await command.ExecuteScalarAsync());
                }

            }

            return newId;
        }



        // 4) метод для обновления фильма в БД
        public static async Task<bool> UpdateFilmAsync(Film film)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();

                string sql = @"UPDATE ""Films"" 
                                   SET Title = @title, 
                                   Description = @description,
                                   Year = @year,
                                   PhotoPath = @photoPath
                                   WHERE Id = @id";


                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", film.Id);
                    command.Parameters.AddWithValue("@title", film.Title);
                    command.Parameters.AddWithValue("@description", film.Description ?? "");
                    command.Parameters.AddWithValue("@year", film.Year);
                    command.Parameters.AddWithValue("@photoPath", film.PhotoPath ?? "");

                    int rowsAffected = await command.ExecuteNonQueryAsync();
                    return rowsAffected > 0;
                }

            }
        }



        // 5) метод для удаления фильма в БД
        public static async Task<bool> DeleteFilmAsync(int id)
        {
            using (NpgsqlConnection connection = new NpgsqlConnection(connectionString))
            {
                await connection.OpenAsync();

                string sql = "DELETE FROM \"Films\" WHERE Id = @id";

                using (NpgsqlCommand command = new NpgsqlCommand(sql, connection))
                {
                    command.Parameters.AddWithValue("@id", id);

                    int rowsAffected = await command.ExecuteNonQueryAsync();
                    return rowsAffected > 0;
                }

            }
        }



    }



}