﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using hw_admin_panel_29062026_05072026.Models; // ++
using hw_admin_panel_29062026_05072026.Database; // ++


namespace hw_admin_panel_29062026_05072026.Controllers
{
    [ApiController]
    [Route("api/films")] // было до этого [Route("call_api/films")]
    public class FilmController : ControllerBase
    {
        // 1) получение всех данных
        [HttpGet("get")]
        public async Task<IActionResult> GetAll()
        {
            var films = await FilmData.GetAllFilmsAsync();
            return Ok(films);
        }

        // 2) получение данных по id
        [HttpGet("get/{id}")]
        public async Task<IActionResult> GetByID(int id)
        {
            var film = await FilmData.GetFilmByIdAsync(id);
            if (film == null)
                return NotFound($"Фильм с ID: {id} не найден!");
            return Ok(film);
        }

        // 3) добавление новой записи
        [HttpPost("add")]
        public async Task<IActionResult> Create([FromBody] Film newFilm)
        {
            if (newFilm == null)
                return BadRequest("Тело запроса не может быть пустым");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            int newId = await FilmData.AddFilmAsync(newFilm);
            newFilm.Id = newId;

            // если не было указано фото, то обновляем фото
            if (string.IsNullOrEmpty(newFilm.PhotoPath))
            {
                newFilm.PhotoPath = $"/images/film_{newId}.png";
                await FilmData.UpdateFilmAsync(newFilm);
            }

            return CreatedAtAction(nameof(GetByID), new { id = newId }, newFilm);
        }

        // 4) редактирование записи по id
        [HttpPut("update/{id}")]
        public async Task<IActionResult> UpdateFilmById(int id, [FromBody] Film updatedFilm)
        {
            if (updatedFilm == null)
                return BadRequest("Тело запроса не может быть пустым");

            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // проверка - существует ли фильм 
            Film existingFilm = await FilmData.GetFilmByIdAsync(id);
            if (existingFilm == null)
                return NotFound($"Фильм с ID: {id} не найден.");

            // обновляем данные
            existingFilm.Title = updatedFilm.Title;
            existingFilm.Description = updatedFilm.Description;
            existingFilm.Year = updatedFilm.Year;

            // если есть новый путь к фото - обновляем
            if (!string.IsNullOrEmpty(updatedFilm.PhotoPath))
            {
                existingFilm.PhotoPath = updatedFilm.PhotoPath;
            }

            bool updated = await FilmData.UpdateFilmAsync(existingFilm);
            if (!updated)
                return StatusCode(500, "Ошибка при обновлении данных");

            return Ok($"Данные у фильма {id} - изменены успешно.");
        }

        // 5) удаление записи по id
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteByID(int id)
        {
            bool deleted = await FilmData.DeleteFilmAsync(id);
            if (!deleted)
                return NotFound($"Фильм с ID: {id} не найден. Удаление элемента невозможно!");

            return Ok($"Фильм с ID = {id} успешно удален!");
        }
    }
}
