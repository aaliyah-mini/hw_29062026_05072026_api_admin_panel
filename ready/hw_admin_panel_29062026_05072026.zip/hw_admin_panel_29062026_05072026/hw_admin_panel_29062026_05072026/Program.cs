using Microsoft.AspNetCore.Cors;
using Microsoft.Extensions.Options;
using static System.Net.WebRequestMethods;

Console.OutputEncoding = System.Text.Encoding.UTF8;

var builder = WebApplication.CreateBuilder(args);

//Добавить к проекту поддержку CORS для разрешения запросов с других IP-Адресов.
builder.Services.AddCors
    (
    Options =>
    {
        Options.AddPolicy("AllowAll", policy => //Подключение с любого IP
        {
            policy.AllowAnyOrigin() //Подключение с любого Порта
                  .AllowAnyMethod()  //Уточнение , какие ТИПЫ методов(API) можно вызвать. В данном случае - все.
                  .AllowAnyHeader(); //Уточнение , какие КОНТРОЛЛЕРЫ можно использовать в запросе. В данном случае - все.
        });
    });

builder.Services.AddControllers();

var app = builder.Build();

//// +++ добавила
//// ВАЖНО: Добавляем поддержку статических файлов (для изображений)
//app.UseStaticFiles(); // это позволит отдавать файлы из папки wwwroot


app.UseCors("AllowAll");
app.MapControllers();

app.Run();