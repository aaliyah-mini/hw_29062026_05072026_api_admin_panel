﻿namespace hw_admin_panel_29062026_05072026.Models
{
    public class Film
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public int Year { get; set; }
        public string PhotoPath { get; set; } = string.Empty;
    }
}
